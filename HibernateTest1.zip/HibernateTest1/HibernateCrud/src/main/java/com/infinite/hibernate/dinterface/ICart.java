package com.infinite.hibernate.dinterface;
import com.infinite.hibernate.pojo.Cart;
public interface ICart {	 
		public void create(String name, int amount, int quantity, int totalprice, Cart c) {
		public void update();
		public void delete();

}
